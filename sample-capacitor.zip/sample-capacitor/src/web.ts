import { WebPlugin } from '@capacitor/core';
import { SampleCapacitorPlugin } from './definitions';

export class SampleCapacitorWeb extends WebPlugin implements SampleCapacitorPlugin {
  constructor() {
    super({
      name: 'SampleCapacitor',
      platforms: ['web']
    });
  }

  async echo(options: { value: string }): Promise<{value: string}> {
    console.log('ECHO', options);
    return options;
  }
}

const SampleCapacitor = new SampleCapacitorWeb();

export { SampleCapacitor };

import { registerWebPlugin } from '@capacitor/core';
registerWebPlugin(SampleCapacitor);
