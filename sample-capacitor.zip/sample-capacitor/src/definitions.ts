declare module "@capacitor/core" {
  interface PluginRegistry {
    SampleCapacitor: SampleCapacitorPlugin;
  }
}

export interface SampleCapacitorPlugin {
  echo(options: { value: string }): Promise<{value: string}>;
}
